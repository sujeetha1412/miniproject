package oracletest;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

public class WelcomePage extends JFrame
{
    BufferedImage bgImg;
    BufferedImage logoImg;

    JPanel bg;

    JButton btnStart, btnExit;

    // Design size: everything is positioned in this coordinate space
    int W = 1672;
    int H = 901;

    public WelcomePage()
    {
        setTitle("Human-Animal Safety Alert & Rescue System");

        // Load background and logo images
        try
        {
            bgImg = ImageIO.read(
                getClass().getResource(
                    "/oracletest/forest_background.png.jpgg.png"
                )
            );

            logoImg = ImageIO.read(
                getClass().getResource(
                    "/oracletest/wildlife_logo.jpg"
                )
            );
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(this,
                "Image not found! Check background and logo filenames.");
            e.printStackTrace();
            return;
        }

        // Background panel
        bg = new JPanel(null)
        {
            protected void paintComponent(Graphics g)
            {
                super.paintComponent(g);

                Graphics2D g2 = (Graphics2D) g.create();

                g2.scale(
                    getWidth() / (double) W,
                    getHeight() / (double) H
                );

                g2.setRenderingHint(
                    RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON
                );

                // Background image
                g2.drawImage(bgImg, 0, 0, W, H, this);

                // Green title box
                g2.setColor(new Color(0, 35, 18));
                g2.fillRoundRect(60, 195, 880, 535, 40, 40);

                // Gold border
                g2.setColor(new Color(255, 210, 30));
                g2.setStroke(new BasicStroke(3));
                g2.drawRoundRect(60, 195, 880, 535, 40, 40);

                // Elephant logo
                if (logoImg != null)
                {
                    Graphics2D logoGraphics =
                        (Graphics2D) g2.create();

                    logoGraphics.setRenderingHint(
                        RenderingHints.KEY_ANTIALIASING,
                        RenderingHints.VALUE_ANTIALIAS_ON
                    );

                    // Circular clipping
                    logoGraphics.setClip(
                        new java.awt.geom.Ellipse2D.Double(
                            410, 145, 210, 210
                        )
                    );

                    logoGraphics.drawImage(
                        logoImg,
                        410, 145, 210, 210,
                        this
                    );

                    logoGraphics.dispose();

                    // Gold circular border
                    g2.setColor(new Color(255, 200, 25));
                    g2.setStroke(new BasicStroke(5));
                    g2.drawOval(410, 145, 210, 210);
                }

                // Main title
                g2.setColor(new Color(255, 245, 220));
                g2.setFont(new Font("Georgia", Font.BOLD, 68));

                center(g2, "HUMAN-ANIMAL", 500, 430);

                // Second title
                g2.setColor(new Color(255, 195, 20));
                g2.setFont(new Font("Georgia", Font.BOLD, 34));

                center(g2,
                    "SAFETY ALERT & RESCUE SYSTEM",
                    500, 485);

                // Divider
                g2.setColor(new Color(255, 205, 20));
                g2.setStroke(new BasicStroke(4));

                g2.drawLine(150, 520, 480, 520);
                g2.drawLine(570, 520, 850, 520);

                // Paw decoration
                g2.fillOval(505, 505, 17, 17);
                g2.fillOval(520, 495, 17, 17);
                g2.fillOval(535, 505, 17, 17);
                g2.fillOval(520, 520, 18, 15);

                // Slogan
                g2.setColor(new Color(255, 245, 220));
                g2.setFont(new Font("Georgia", Font.BOLD, 29));

                center(g2,
                    "Protecting people. Protecting wildlife.",
                    500, 585);

                // Footer
                g2.setColor(new Color(0, 45, 25));
                g2.fillRect(0, 850, W, 51);

                g2.setColor(Color.WHITE);
                g2.setFont(new Font("Serif",
                    Font.BOLD | Font.ITALIC, 24));

                center(g2,
                    "-----------------Wildlife Awareness • Early alerts • Safe rescue-----------------",
                    W / 2, 882);

                g2.dispose();
            }
        };

        bg.setPreferredSize(new Dimension(1200, 647));

        setContentPane(bg);

        // Create buttons
        btnStart = new JButton("GET STARTED");
        btnExit = new JButton("EXIT");

        // Button styling
        style(btnStart,
            new Color(0, 55, 25),
            Color.WHITE);

        style(btnExit,
            new Color(255, 225, 160),
            new Color(0, 65, 30));

        // Add buttons
        bg.add(btnStart);
        bg.add(btnExit);

        // GET STARTED button
        btnStart.addActionListener(e ->
        {
            dispose();
            new LoginPage();
        });

        // EXIT button
        btnExit.addActionListener(e ->
        {
            System.exit(0);
        });

        // FIX: re-position the buttons every time the window is resized,
        // so they stay aligned with the scaled background drawing
        bg.addComponentListener(new ComponentAdapter()
        {
            public void componentResized(ComponentEvent e)
            {
                setButtons();
            }
        });

        // Window settings
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setResizable(true);

        pack();

        setMinimumSize(new Dimension(1000, 600));

        setLocationRelativeTo(null);

        setVisible(true);

        setButtons();
    }

    // Center text
    void center(Graphics2D g, String s, int x, int y)
    {
        g.drawString(
            s,
            x - g.getFontMetrics().stringWidth(s) / 2,
            y
        );
    }

    // Button design
    void style(JButton b, Color bgColor, Color textColor)
    {
        b.setFont(new Font("Arial", Font.BOLD, 25));

        b.setBackground(bgColor);
        b.setForeground(textColor);

        b.setOpaque(true);
        b.setFocusPainted(false);

        b.setBorder(BorderFactory.createLineBorder(
            new Color(255, 205, 20), 4
        ));

        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    // FIX: button positions are given in the same design space (W x H)
    // as the painted background, then scaled to the current window size
    void setButtons()
    {
        if (bg == null || bg.getWidth() == 0 || bg.getHeight() == 0)
            return;

        double sx = bg.getWidth() / (double) W;
        double sy = bg.getHeight() / (double) H;

        // Design-space values (title box is x=60..940, centre x=500)
        int btnW = 280;
        int btnH = 64;
        int gap  = 40;
        int y    = 630;                               // below the slogan, inside the box
        int x1   = 500 - (btnW * 2 + gap) / 2;        // centred under the title
        int x2   = x1 + btnW + gap;

        btnStart.setBounds(
            (int) (x1 * sx), (int) (y * sy),
            (int) (btnW * sx), (int) (btnH * sy)
        );

        btnExit.setBounds(
            (int) (x2 * sx), (int) (y * sy),
            (int) (btnW * sx), (int) (btnH * sy)
        );

        // Scale the text size with the window too
        float fontSize = (float) (25 * Math.min(sx, sy));
        btnStart.setFont(btnStart.getFont().deriveFont(fontSize));
        btnExit.setFont(btnExit.getFont().deriveFont(fontSize));
    }

    public static void main(String[] args)
    {
        SwingUtilities.invokeLater(() ->
        {
            new WelcomePage();
        });
    }
}