package oracletest;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.print.PrinterException;
import java.io.File;
import java.io.FileWriter;
import java.sql.*;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * Reports view shown INSIDE the CommonDashboard window
 * (the dashboard sidebar stays on the left).
 *
 * Report type + date filter, summary cards, day / week / month wise table,
 * report details, summary and alert message.
 *
 * Saved in REPORT table (admin / forest officer):
 *   REPORT_TYPE    = "Day Wise Report" / "Week Wise Report" / "Month Wise Report"
 *   REPORT_DETAILS = "yyyy-MM-dd|yyyy-MM-dd|D"   (23 chars, fits VARCHAR2(25))
 */
public class ReportsPage extends JPanel {

    private final int userId;
    private final String username;
    private final String role;

    private final Color background = new Color(246, 248, 245);
    private final Color white = Color.WHITE;
    private final Color darkGreen = new Color(24, 75, 53);
    private final Color green = new Color(53, 125, 85);
    private final Color lightGreen = new Color(226, 241, 230);
    private final Color textColor = new Color(45, 55, 48);
    private final Color mutedText = new Color(115, 125, 117);
    private final Color borderColor = new Color(225, 232, 225);
    private final Color riskHigh = new Color(204, 76, 76);
    private final Color riskMedium = new Color(222, 150, 30);
    private final Color riskLow = new Color(76, 155, 105);
    private final Color blue = new Color(70, 130, 180);
    private final Color purple = new Color(150, 110, 170);

    private static final String[] MODE_CODES = { "D", "W", "M" };
    private static final String[] MODE_TYPES = {
            "Day Wise Report", "Week Wise Report", "Month Wise Report" };

    private final SimpleDateFormat dmy = new SimpleDateFormat("dd-MM-yyyy");

    // filter
    private JRadioButton dayWise;
    private JRadioButton weekWise;
    private JRadioButton monthWise;
    private JTextField fromDate;
    private JTextField toDate;

    // summary cards
    private JLabel sumSightings;
    private JLabel sumConflicts;
    private JLabel sumHigh;
    private JLabel sumRescue;

    // table
    private JLabel tableHeading;
    private JTable reportTable;
    private DefaultTableModel reportModel;

    // details
    private JLabel reportID;
    private JLabel generatedDate;
    private JLabel reportType;
    private JLabel detailFrom;
    private JLabel detailTo;

    // summary box
    private JLabel bulletSightings;
    private JLabel bulletConflicts;
    private JLabel bulletHigh;
    private JLabel bulletRescue;
    private JTextArea remarksArea;

    // alert message
    private JPanel alertCard;
    private JLabel alertTitle;
    private JLabel alertIcon;
    private JTextArea alertText;

    private String lastGenerated = "-";

    private static class Result {
        List<Object[]> rows = new ArrayList<Object[]>();
        int sightings, conflicts, highAlerts, rescue;
    }

    // Panel that always takes the width of the scroll pane (no sideways scroll)
    private static class ScrollBody extends JPanel implements Scrollable {
        @Override
        public Dimension getPreferredScrollableViewportSize() {
            return getPreferredSize();
        }

        @Override
        public int getScrollableUnitIncrement(Rectangle r, int o, int d) {
            return 20;
        }

        @Override
        public int getScrollableBlockIncrement(Rectangle r, int o, int d) {
            return 150;
        }

        @Override
        public boolean getScrollableTracksViewportWidth() {
            return true;
        }

        @Override
        public boolean getScrollableTracksViewportHeight() {
            return false;
        }
    }

    public ReportsPage(int userId, String username, String role) {
        this.userId = userId;
        this.username = username;
        this.role = role;
        dmy.setLenient(false);

        setLayout(new BorderLayout());
        setBackground(background);
        setBorder(new EmptyBorder(25, 30, 25, 30));

        add(createHeader(), BorderLayout.NORTH);
        add(createContent(), BorderLayout.CENTER);
    }

    // Called by CommonDashboard every time the Reports menu is clicked
    public void refresh() {
        generate(false);
    }

    private boolean canManage() {
        return role.equalsIgnoreCase("Admin")
                || role.equalsIgnoreCase("Forest Officer");
    }

    // ---------------------------------------------------------
    // HEADER + CONTENT
    // ---------------------------------------------------------

    private JPanel createHeader() {
        JPanel header = new JPanel();
        header.setBackground(background);
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));

        JLabel title = new JLabel("Reports");
        title.setFont(new Font("Segoe UI", Font.BOLD, 28));
        title.setForeground(darkGreen);
        JLabel sub = new JLabel(canManage()
                ? "Generate day, week or month wise reports of sightings and risk"
                : "Day, week and month wise reports of sightings and risk");
        sub.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        sub.setForeground(mutedText);

        header.add(title);
        header.add(Box.createVerticalStrut(5));
        header.add(sub);
        return header;
    }

    private JScrollPane createContent() {
        ScrollBody body = new ScrollBody();
        body.setBackground(background);
        body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));
        body.setBorder(new EmptyBorder(22, 0, 0, 0));

        body.add(createTopRow());
        body.add(Box.createVerticalStrut(16));
        body.add(createTableCard());
        body.add(Box.createVerticalStrut(16));
        body.add(createBottomRow());

        JScrollPane scroll = new JScrollPane(body,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scroll.setBorder(null);
        scroll.getViewport().setBackground(background);
        scroll.getVerticalScrollBar().setUnitIncrement(20);
        return scroll;
    }

    private JPanel card() {
        JPanel c = new JPanel();
        c.setBackground(white);
        c.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(borderColor),
                new EmptyBorder(14, 16, 14, 16)));
        return c;
    }

    private JButton button(String text, boolean primary) {
        JButton b = new JButton(text);
        b.setFont(new Font("Segoe UI", Font.BOLD, 13));
        b.setFocusPainted(false);
        b.setOpaque(true);
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        if (primary) {
            b.setForeground(Color.WHITE);
            b.setBackground(green);
            b.setBorder(new EmptyBorder(10, 22, 10, 22));
        } else {
            b.setForeground(darkGreen);
            b.setBackground(Color.WHITE);
            b.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(190, 200, 190)),
                    new EmptyBorder(9, 16, 9, 16)));
        }
        return b;
    }

    private JLabel cardTitle(String text) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("Segoe UI", Font.BOLD, 15));
        l.setForeground(textColor);
        return l;
    }

    private Color tint(Color c, double amount) {
        int r = (int) (255 - (255 - c.getRed()) * amount);
        int g = (int) (255 - (255 - c.getGreen()) * amount);
        int b = (int) (255 - (255 - c.getBlue()) * amount);
        return new Color(r, g, b);
    }

    // ---- top row: report type + date (left), summary cards (right) ----

    private JPanel createTopRow() {
        JPanel row = new JPanel(new BorderLayout(16, 0));
        row.setOpaque(false);
        row.setAlignmentX(Component.LEFT_ALIGNMENT);
        row.setPreferredSize(new Dimension(0, 268));
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 268));

        JPanel left = new JPanel();
        left.setOpaque(false);
        left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
        left.setPreferredSize(new Dimension(255, 0));

        JPanel typeCard = card();
        typeCard.setLayout(new BoxLayout(typeCard, BoxLayout.Y_AXIS));
        dayWise = radio("Day Wise Report", true);
        weekWise = radio("Week Wise Report", false);
        monthWise = radio("Month Wise Report", false);
        ButtonGroup group = new ButtonGroup();
        group.add(dayWise);
        group.add(weekWise);
        group.add(monthWise);
        JLabel t1 = cardTitle("Report Type");
        t1.setAlignmentX(Component.LEFT_ALIGNMENT);
        typeCard.add(t1);
        typeCard.add(Box.createVerticalStrut(6));
        typeCard.add(dayWise);
        typeCard.add(weekWise);
        typeCard.add(monthWise);
        typeCard.setMaximumSize(new Dimension(Integer.MAX_VALUE, 135));

        long now = System.currentTimeMillis();
        fromDate = dateField(dmy.format(new java.util.Date(now - 365L * 86400000L)));
        toDate = dateField(dmy.format(new java.util.Date(now)));

        JPanel dateCard = card();
        dateCard.setLayout(new GridBagLayout());
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(5, 0, 5, 8);
        g.anchor = GridBagConstraints.WEST;
        g.gridx = 0;
        g.gridy = 0;
        g.gridwidth = 2;
        dateCard.add(cardTitle("Select Date"), g);
        g.gridwidth = 1;
        g.gridy = 1;
        dateCard.add(smallLabel("From Date :"), g);
        g.gridx = 1;
        dateCard.add(fromDate, g);
        g.gridx = 0;
        g.gridy = 2;
        dateCard.add(smallLabel("To Date :"), g);
        g.gridx = 1;
        dateCard.add(toDate, g);

        JButton generate = button("Generate Report", true);
        generate.addActionListener(e -> generate(canManage()));
        g.gridx = 0;
        g.gridy = 3;
        g.gridwidth = 2;
        g.anchor = GridBagConstraints.CENTER;
        g.insets = new Insets(10, 0, 0, 0);
        dateCard.add(generate, g);

        left.add(typeCard);
        left.add(Box.createVerticalStrut(12));
        left.add(dateCard);

        JPanel summary = card();
        summary.setLayout(new BorderLayout(0, 12));
        sumSightings = bigNumber();
        sumConflicts = bigNumber();
        sumHigh = bigNumber();
        sumRescue = bigNumber();

        JPanel tiles = new JPanel(new GridLayout(1, 4, 12, 0));
        tiles.setOpaque(false);
        tiles.add(summaryTile("Total Sightings", sumSightings, green));
        tiles.add(summaryTile("Total Conflicts", sumConflicts, blue));
        tiles.add(summaryTile("High Risk Alerts", sumHigh, riskHigh));
        tiles.add(summaryTile("Rescue Actions", sumRescue, purple));
        summary.add(cardTitle("Report Summary"), BorderLayout.NORTH);
        summary.add(tiles, BorderLayout.CENTER);

        row.add(left, BorderLayout.WEST);
        row.add(summary, BorderLayout.CENTER);
        return row;
    }

    private JRadioButton radio(String text, boolean selected) {
        JRadioButton r = new JRadioButton(text, selected);
        r.setBackground(white);
        r.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        r.setForeground(textColor);
        r.setAlignmentX(Component.LEFT_ALIGNMENT);
        return r;
    }

    private JLabel smallLabel(String text) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        l.setForeground(textColor);
        return l;
    }

    private JTextField dateField(String value) {
        JTextField f = new JTextField(value, 9);
        f.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        f.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 208, 200)),
                new EmptyBorder(6, 8, 6, 8)));
        return f;
    }

    private JLabel bigNumber() {
        JLabel l = new JLabel("0", SwingConstants.CENTER);
        l.setFont(new Font("Segoe UI", Font.BOLD, 32));
        l.setAlignmentX(Component.CENTER_ALIGNMENT);
        return l;
    }

    private JPanel summaryTile(String heading, JLabel value, Color accent) {
        JPanel t = new JPanel();
        t.setBackground(tint(accent, 0.10));
        t.setLayout(new BoxLayout(t, BoxLayout.Y_AXIS));
        t.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(tint(accent, 0.35)),
                new EmptyBorder(18, 8, 16, 8)));
        JLabel h = new JLabel(heading, SwingConstants.CENTER);
        h.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        h.setForeground(accent.darker());
        h.setAlignmentX(Component.CENTER_ALIGNMENT);
        value.setForeground(accent.darker());
        t.add(Box.createVerticalGlue());
        t.add(h);
        t.add(Box.createVerticalStrut(10));
        t.add(value);
        t.add(Box.createVerticalGlue());
        return t;
    }

    // ---- report table ----

    private JPanel createTableCard() {
        JPanel c = card();
        c.setLayout(new BorderLayout(0, 10));
        c.setAlignmentX(Component.LEFT_ALIGNMENT);
        c.setPreferredSize(new Dimension(0, 360));
        c.setMaximumSize(new Dimension(Integer.MAX_VALUE, 360));

        tableHeading = new JLabel("Day Wise Report");
        tableHeading.setFont(new Font("Segoe UI", Font.BOLD, 16));
        tableHeading.setForeground(textColor);

        JButton pdf = button("Export PDF", false);
        pdf.addActionListener(e -> exportPdf());
        JButton excel = button("Export Excel", false);
        excel.addActionListener(e -> exportCsv());

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        buttons.setOpaque(false);
        buttons.add(pdf);
        buttons.add(excel);

        JPanel top = new JPanel(new BorderLayout());
        top.setOpaque(false);
        top.add(tableHeading, BorderLayout.WEST);
        top.add(buttons, BorderLayout.EAST);

        reportModel = new DefaultTableModel(new String[] { "Report ID",
                "Report Generated Date", "Date", "Area", "Animal", "Sighting Count",
                "Conflict Count", "Risk Level", "Alerts Generated" }, 0) {
            @Override
            public boolean isCellEditable(int r, int col) {
                return false;
            }
        };
        reportTable = new JTable(reportModel);
        styleTable(reportTable);
        reportTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                showRowDetails();
            }
        });

        JScrollPane sp = new JScrollPane(reportTable);
        sp.setBorder(BorderFactory.createLineBorder(borderColor));
        sp.getViewport().setBackground(white);

        c.add(top, BorderLayout.NORTH);
        c.add(sp, BorderLayout.CENTER);
        return c;
    }

    private class CellStyler extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean selected, boolean focus, int row, int col) {
            super.getTableCellRendererComponent(table, value, selected, focus, row, col);
            setHorizontalAlignment(SwingConstants.CENTER);
            if (col == 7 && !selected) {
                String v = value == null ? "" : String.valueOf(value).toUpperCase();
                setFont(getFont().deriveFont(Font.BOLD));
                if (v.startsWith("HIGH")) {
                    setForeground(riskHigh);
                } else if (v.startsWith("MEDIUM")) {
                    setForeground(riskMedium);
                } else if (v.startsWith("LOW")) {
                    setForeground(riskLow);
                } else {
                    setForeground(textColor);
                }
            } else if (!selected) {
                setForeground(textColor);
            }
            return this;
        }
    }

    private void styleTable(JTable t) {
        t.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        t.setRowHeight(32);
        t.setBackground(Color.WHITE);
        t.setForeground(textColor);
        t.setGridColor(borderColor);
        t.setSelectionBackground(lightGreen);
        t.setSelectionForeground(darkGreen);
        t.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        t.setDefaultRenderer(Object.class, new CellStyler());
        t.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        t.getTableHeader().setBackground(new Color(42, 90, 60));
        t.getTableHeader().setForeground(Color.WHITE);
        t.getTableHeader().setReorderingAllowed(false);
        ((DefaultTableCellRenderer) t.getTableHeader().getDefaultRenderer())
                .setHorizontalAlignment(SwingConstants.CENTER);
    }

    // ---- bottom row: details, summary, alert message ----

    private JPanel createBottomRow() {
        JPanel row = new JPanel(new GridBagLayout());
        row.setOpaque(false);
        row.setAlignmentX(Component.LEFT_ALIGNMENT);
        row.setPreferredSize(new Dimension(0, 270));
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 270));

        GridBagConstraints g = new GridBagConstraints();
        g.fill = GridBagConstraints.BOTH;
        g.weighty = 1;
        g.gridy = 0;

        // details
        reportID = valueLabel();
        generatedDate = valueLabel();
        reportType = valueLabel();
        detailFrom = valueLabel();
        detailTo = valueLabel();

        JPanel details = card();
        details.setLayout(new BorderLayout(0, 10));
        JPanel dGrid = new JPanel(new GridBagLayout());
        dGrid.setOpaque(false);
        addRow(dGrid, 0, "Report ID", reportID);
        addRow(dGrid, 1, "Generated Date", generatedDate);
        addRow(dGrid, 2, "Report Type", reportType);
        addRow(dGrid, 3, "From Date", detailFrom);
        addRow(dGrid, 4, "To Date", detailTo);
        details.add(cardTitle("Report Details"), BorderLayout.NORTH);
        details.add(dGrid, BorderLayout.CENTER);

        g.gridx = 0;
        g.weightx = 1.0;
        g.insets = new Insets(0, 0, 0, 14);
        row.add(details, g);

        // summary
        bulletSightings = valueLabel();
        bulletConflicts = valueLabel();
        bulletHigh = valueLabel();
        bulletRescue = valueLabel();

        JPanel sum = card();
        sum.setLayout(new BorderLayout(0, 8));
        JPanel sGrid = new JPanel(new GridBagLayout());
        sGrid.setOpaque(false);
        addRow(sGrid, 0, "\u2022  Total Sightings", bulletSightings);
        addRow(sGrid, 1, "\u2022  Total Conflicts", bulletConflicts);
        addRow(sGrid, 2, "\u2022  High Risk Alerts", bulletHigh);
        addRow(sGrid, 3, "\u2022  Rescue Actions", bulletRescue);

        remarksArea = new JTextArea("-");
        remarksArea.setEditable(false);
        remarksArea.setLineWrap(true);
        remarksArea.setWrapStyleWord(true);
        remarksArea.setOpaque(false);
        remarksArea.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        remarksArea.setForeground(textColor);
        JLabel remarksCap = smallLabel("Remarks :");
        remarksCap.setFont(new Font("Segoe UI", Font.BOLD, 13));
        JPanel remarks = new JPanel(new BorderLayout(0, 4));
        remarks.setOpaque(false);
        remarks.add(remarksCap, BorderLayout.NORTH);
        remarks.add(remarksArea, BorderLayout.CENTER);

        sum.add(cardTitle("Summary :"), BorderLayout.NORTH);
        JPanel sCenter = new JPanel(new BorderLayout(0, 8));
        sCenter.setOpaque(false);
        sCenter.add(sGrid, BorderLayout.NORTH);
        sCenter.add(remarks, BorderLayout.CENTER);
        sum.add(sCenter, BorderLayout.CENTER);

        g.gridx = 1;
        g.weightx = 1.2;
        row.add(sum, g);

        // alert message
        alertCard = new JPanel(new BorderLayout(0, 8));
        alertTitle = new JLabel("Alert Message");
        alertTitle.setFont(new Font("Segoe UI", Font.BOLD, 15));
        alertIcon = new JLabel("\u26A0");
        alertIcon.setFont(new Font("Segoe UI Symbol", Font.BOLD, 38));
        alertIcon.setVerticalAlignment(SwingConstants.TOP);
        alertText = new JTextArea();
        alertText.setEditable(false);
        alertText.setLineWrap(true);
        alertText.setWrapStyleWord(true);
        alertText.setOpaque(false);
        alertText.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        alertText.setForeground(textColor);
        JLabel from = new JLabel("- Forest Department", SwingConstants.RIGHT);
        from.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        from.setForeground(textColor);

        JPanel mid = new JPanel(new BorderLayout(10, 0));
        mid.setOpaque(false);
        mid.add(alertIcon, BorderLayout.WEST);
        mid.add(alertText, BorderLayout.CENTER);
        alertCard.add(alertTitle, BorderLayout.NORTH);
        alertCard.add(mid, BorderLayout.CENTER);
        alertCard.add(from, BorderLayout.SOUTH);
        setAlertStyle(riskLow, "Generate a report to see the alert message.");

        g.gridx = 2;
        g.weightx = 1.0;
        g.insets = new Insets(0, 0, 0, 0);
        row.add(alertCard, g);
        return row;
    }

    private JLabel valueLabel() {
        JLabel l = new JLabel("-");
        l.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        l.setForeground(textColor);
        return l;
    }

    private void addRow(JPanel grid, int y, String caption, JLabel value) {
        GridBagConstraints g = new GridBagConstraints();
        g.gridy = y;
        g.anchor = GridBagConstraints.WEST;
        g.insets = new Insets(4, 0, 4, 8);
        g.gridx = 0;
        JLabel k = smallLabel(caption);
        k.setPreferredSize(new Dimension(125, 20));
        grid.add(k, g);
        g.gridx = 1;
        grid.add(smallLabel(":"), g);
        g.gridx = 2;
        g.weightx = 1;
        g.fill = GridBagConstraints.HORIZONTAL;
        grid.add(value, g);
    }

    private void setAlertStyle(Color accent, String message) {
        alertCard.setBackground(tint(accent, 0.10));
        alertCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(tint(accent, 0.45)),
                new EmptyBorder(14, 16, 14, 16)));
        alertTitle.setForeground(accent);
        alertIcon.setForeground(accent);
        alertText.setText(message);
    }

    // ---------------------------------------------------------
    // GENERATE
    // ---------------------------------------------------------

    private int selectedMode() {
        return weekWise.isSelected() ? 1 : monthWise.isSelected() ? 2 : 0;
    }

    private java.sql.Date parse(String text) {
        try {
            return new java.sql.Date(dmy.parse(text.trim()).getTime());
        } catch (Exception ex) {
            return null;
        }
    }

    private void generate(boolean save) {
        java.sql.Date from = parse(fromDate.getText());
        java.sql.Date to = parse(toDate.getText());
        if (from == null || to == null) {
            JOptionPane.showMessageDialog(this,
                    "Please enter valid dates in the format dd-mm-yyyy.");
            return;
        }
        if (from.after(to)) {
            JOptionPane.showMessageDialog(this,
                    "The 'From' date cannot be after the 'To' date.");
            return;
        }
        runReport(from, to, selectedMode(), save);
    }

    private void runReport(final java.sql.Date from, final java.sql.Date to,
                           final int mode, final boolean save) {
        SwingWorker<Object[], Void> worker = new SwingWorker<Object[], Void>() {
            @Override
            protected Object[] doInBackground() throws Exception {
                try (Connection con = DBConnection.getConnection()) {
                    Result r = query(con, from, to, mode);
                    String saveError = null;
                    if (save) {
                        try {
                            saveReport(con, mode, from, to);
                        } catch (SQLException ex) {
                            saveError = ex.getMessage();
                        }
                    }
                    return new Object[] { r, saveError };
                }
            }

            @Override
            protected void done() {
                try {
                    Object[] out = get();
                    showResult((Result) out[0], mode, from, to);
                    if (out[1] != null) {
                        JOptionPane.showMessageDialog(ReportsPage.this,
                                "The report was generated but could not be saved:\n"
                                + out[1], "Save Warning",
                                JOptionPane.WARNING_MESSAGE);
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(ReportsPage.this,
                            "Unable to generate the report:\n" + ex.getMessage(),
                            "Database Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        };
        worker.execute();
    }

    private String nz(String v) {
        return v == null || v.trim().isEmpty() ? "-" : v.trim();
    }

    private Result query(Connection con, java.sql.Date from, java.sql.Date to,
                         int mode) throws SQLException {
        String unit = mode == 0 ? "DD" : mode == 1 ? "IW" : "MM";
        String fmt = mode == 2 ? "Mon YYYY" : "DD-MM-YYYY";

        String sql = "SELECT TO_CHAR(X.P, '" + fmt + "') AS PERIOD, X.AREA_NAME, "
                + "X.SPECIES_NAME, COUNT(*) AS CNT, "
                + "SUM(CASE WHEN X.HAS_CONFLICT = 1 THEN 1 ELSE 0 END) AS CONFLICTS, "
                + "MAX(X.LVL_RANK) AS LVL_RANK, SUM(X.ALERTS) AS ALERTS, "
                + "SUM(X.HALERTS) AS HALERTS, SUM(X.RESCUE) AS RESCUE "
                + "FROM (SELECT TRUNC(s.SIGHTING_DATE, '" + unit + "') AS P, "
                + "s.AREA_NAME, s.SPECIES_NAME, s.HAS_CONFLICT, "
                + "CASE WHEN s.NEEDS_RESCUE = 1 THEN 1 ELSE 0 END AS RESCUE, "
                + "(SELECT NVL(MAX(CASE WHEN UPPER(r.RISK_LEVEL) LIKE 'HIGH%' THEN 3 "
                + "WHEN UPPER(r.RISK_LEVEL) LIKE 'MEDIUM%' THEN 2 "
                + "WHEN UPPER(r.RISK_LEVEL) LIKE 'LOW%' THEN 1 ELSE 0 END), 0) "
                + "FROM RISK_RECORD r WHERE r.SIGHTING_ID = s.SIGHTING_ID) AS LVL_RANK, "
                + "(SELECT COUNT(*) FROM RISK_ALERT a WHERE a.RISK_ID IN "
                + "(SELECT r2.RISK_ID FROM RISK_RECORD r2 "
                + "WHERE r2.SIGHTING_ID = s.SIGHTING_ID)) AS ALERTS, "
                + "(SELECT COUNT(*) FROM RISK_ALERT a2 "
                + "WHERE UPPER(a2.RISK_LEVEL) LIKE 'HIGH%' AND a2.RISK_ID IN "
                + "(SELECT r3.RISK_ID FROM RISK_RECORD r3 "
                + "WHERE r3.SIGHTING_ID = s.SIGHTING_ID)) AS HALERTS "
                + "FROM ANIMAL_SIGHTING s "
                + "WHERE s.SIGHTING_DATE >= ? AND s.SIGHTING_DATE < ? + 1) X "
                + "GROUP BY X.P, X.AREA_NAME, X.SPECIES_NAME "
                + "ORDER BY X.P DESC, X.AREA_NAME";

        Result r = new Result();
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setDate(1, from);
            ps.setDate(2, to);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String period = rs.getString("PERIOD");
                    if (mode == 1) {
                        period = "Week of " + period;
                    }
                    int cnt = rs.getInt("CNT");
                    int conflicts = rs.getInt("CONFLICTS");
                    int rank = rs.getInt("LVL_RANK");
                    int alerts = rs.getInt("ALERTS");
                    String level = rank == 3 ? "High" : rank == 2 ? "Medium"
                            : rank == 1 ? "Low" : "-";
                    r.rows.add(new Object[] { period, nz(rs.getString("AREA_NAME")),
                            nz(rs.getString("SPECIES_NAME")), cnt, conflicts,
                            level, alerts });
                    r.sightings += cnt;
                    r.conflicts += conflicts;
                    r.highAlerts += rs.getInt("HALERTS");
                    r.rescue += rs.getInt("RESCUE");
                }
            }
        }
        return r;
    }

    private void showResult(Result r, int mode, java.sql.Date from,
                            java.sql.Date to) {
        sumSightings.setText(String.valueOf(r.sightings));
        sumConflicts.setText(String.valueOf(r.conflicts));
        sumHigh.setText(String.valueOf(r.highAlerts));
        sumRescue.setText(String.valueOf(r.rescue));

        bulletSightings.setText(String.valueOf(r.sightings));
        bulletConflicts.setText(String.valueOf(r.conflicts));
        bulletHigh.setText(String.valueOf(r.highAlerts));
        bulletRescue.setText(String.valueOf(r.rescue));

        lastGenerated = new SimpleDateFormat("dd-MM-yyyy hh:mm a")
                .format(new java.util.Date());
        tableHeading.setText(MODE_TYPES[mode] + " - " + dmy.format(from)
                + " to " + dmy.format(to));
        reportType.setText(MODE_TYPES[mode]);
        detailFrom.setText(dmy.format(from));
        detailTo.setText(dmy.format(to));
        generatedDate.setText(lastGenerated);

        reportModel.setRowCount(0);
        int best = 0;
        int bestRank = -1;
        int n = 0;
        String topArea = null;
        for (Object[] row : r.rows) {
            String level = String.valueOf(row[5]);
            int rank = level.equals("High") ? 3 : level.equals("Medium") ? 2
                    : level.equals("Low") ? 1 : 0;
            if (rank > bestRank) {
                bestRank = rank;
                best = n;
                if (rank == 3) {
                    topArea = String.valueOf(row[1]);
                }
            }
            reportModel.addRow(new Object[] { "RPT" + (1001 + n), lastGenerated,
                    row[0], row[1], row[2], row[3], row[4], row[5], row[6] });
            n++;
        }

        if (topArea != null) {
            remarksArea.setText("High risk activity reported in " + topArea
                    + " area. People are advised to stay alert.");
        } else if (r.sightings > 0) {
            remarksArea.setText("No high risk activity in this period. "
                    + "Keep monitoring the reported areas.");
        } else {
            remarksArea.setText("No sightings were recorded in this period.");
        }

        if (n > 0) {
            reportTable.setRowSelectionInterval(best, best);
        } else {
            reportID.setText("-");
            setAlertStyle(riskLow, "No sightings were recorded between "
                    + dmy.format(from) + " and " + dmy.format(to) + ".");
        }
    }

    // Selecting a row shows its report ID and alert message
    private void showRowDetails() {
        int vr = reportTable.getSelectedRow();
        if (vr < 0) {
            return;
        }
        int r = reportTable.convertRowIndexToModel(vr);
        String id = String.valueOf(reportModel.getValueAt(r, 0));
        String date = String.valueOf(reportModel.getValueAt(r, 2));
        String area = String.valueOf(reportModel.getValueAt(r, 3));
        String animal = String.valueOf(reportModel.getValueAt(r, 4));
        String level = String.valueOf(reportModel.getValueAt(r, 7));
        reportID.setText(id);

        if (level.equals("High")) {
            setAlertStyle(riskHigh, "High risk of Human-Animal conflict reported in "
                    + area + " area on " + date
                    + ". Please stay alert and avoid movement in forest areas.");
        } else if (level.equals("Medium")) {
            setAlertStyle(riskMedium, "Medium risk of Human-Animal conflict reported in "
                    + area + " area on " + date
                    + ". Please be careful and move in groups near forest areas.");
        } else if (level.equals("Low")) {
            setAlertStyle(riskLow, "Low risk reported in " + area + " area on "
                    + date + ". Stay aware of your surroundings and report any "
                    + "new sightings.");
        } else {
            setAlertStyle(riskLow, animal + " was sighted in " + area + " area on "
                    + date + ". No risk level has been assessed yet.");
        }
    }

    // Saves the report in the REPORT table
    private void saveReport(Connection con, int mode, java.sql.Date from,
                            java.sql.Date to) throws SQLException {
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd");
        String details = f.format(from) + "|" + f.format(to) + "|" + MODE_CODES[mode];

        String sql = "INSERT INTO REPORT (REPORT_TYPE, GENERATED_BY, "
                + "GENERATED_DATE, REPORT_DETAILS) VALUES (?, ?, SYSDATE, ?)";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, MODE_TYPES[mode]);
            ps.setInt(2, userId);
            ps.setString(3, details);
            ps.executeUpdate();
        } catch (SQLException ex) {
            if (ex.getErrorCode() != 1400) {   // 1400 = a NOT NULL column is empty
                throw ex;
            }
            String sql2 = "INSERT INTO REPORT (REPORT_ID, REPORT_TYPE, GENERATED_BY, "
                    + "GENERATED_DATE, REPORT_DETAILS) VALUES "
                    + "((SELECT NVL(MAX(REPORT_ID), 0) + 1 FROM REPORT), ?, ?, SYSDATE, ?)";
            try (PreparedStatement ps = con.prepareStatement(sql2)) {
                ps.setString(1, MODE_TYPES[mode]);
                ps.setInt(2, userId);
                ps.setString(3, details);
                ps.executeUpdate();
            }
        }
    }

    // ---------------------------------------------------------
    // EXPORT
    // ---------------------------------------------------------

    private void exportPdf() {
        if (reportModel.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "There is no report data to export.");
            return;
        }
        JOptionPane.showMessageDialog(this,
                "In the print window choose \"Microsoft Print to PDF\" (or any PDF "
                + "printer) to save this report as a PDF.");
        try {
            reportTable.print(JTable.PrintMode.FIT_WIDTH,
                    new MessageFormat(tableHeading.getText()),
                    new MessageFormat("Page {0}"));
        } catch (PrinterException ex) {
            JOptionPane.showMessageDialog(this,
                    "Unable to print the report:\n" + ex.getMessage(),
                    "Export Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void exportCsv() {
        if (reportModel.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "There is no report data to export.");
            return;
        }
        JFileChooser chooser = new JFileChooser();
        chooser.setSelectedFile(new File("report.csv"));
        if (chooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) {
            return;
        }
        File file = chooser.getSelectedFile();
        try (FileWriter w = new FileWriter(file)) {
            w.write(tableHeading.getText() + "\n\n");
            for (int c = 0; c < reportModel.getColumnCount(); c++) {
                w.write((c > 0 ? "," : "") + reportModel.getColumnName(c));
            }
            w.write("\n");
            for (int r = 0; r < reportModel.getRowCount(); r++) {
                for (int c = 0; c < reportModel.getColumnCount(); c++) {
                    w.write((c > 0 ? "," : "") + "\"" + reportModel.getValueAt(r, c) + "\"");
                }
                w.write("\n");
            }
            JOptionPane.showMessageDialog(this,
                    "Report saved. Open it with Excel:\n" + file.getAbsolutePath());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "Unable to export the report:\n" + ex.getMessage(),
                    "Export Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
